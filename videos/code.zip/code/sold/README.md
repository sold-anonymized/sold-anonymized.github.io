# SOLD: Slot-Attention for Object-centric Latent Dynamics

**Slot-Attention for Object-centric Latent Dynamics (SOLD)** is a model-based reinforcement learning algorithm operating on a structured latent representation in its world model.

![SOLD Overview](assets/sold_overview.png)


##  Installation
Start by installing the [multi-object-fetch](../multi-object-fetch) environment suite.
Then add the SOLD dependencies to the conda environment:
```bash
conda env update --file conda_env.yml
```

## Training
The training routine consists of two stages: [pre-training a SAVi model](#pre-training-a-savi-model) and 
[training a SOLD model](#training-a-sold-model) on top of it.

### Pre-training a SAVi model
SAVi models are pre-trained on static datasets of random trajectories. 
Such datasets can be generated using the following script:
```bash
python generate_dataset.py experiment=my_dataset env.name=finger-spin
```

To train a SAVi model, specify the dataset to be trained on and model parameters such as the number of slots in [`train_savi.yaml`](./sold/configs/train_savi.yaml) and run:
```bash
python train_savi.py experiment=my_savi_model
```

<details>
    <summary><i>Show sample pre-training results</i></summary>
    Good SAVi models should learn to split the scene into meaningful objects and keep slots assigned to the same object over time.
    Examples of SAVi models pre-trained for a reaching and picking task are shown below.
    <img src="assets/savi_reach_red.png" width="49%" align="top"> <img src="assets/savi_pick_red.png" width="49%" align="top">
</details>

### Training a SOLD model

To train SOLD, a checkpoint path to the pre-trained SAVi model is required, which can be specified in the [`train_sold.yaml`](./sold/configs/train_sold.yaml) configuration file.
Then, to start the training, run:
```bash
python train_sold.py
```
All results are stored in the [`experiments`](./experiments) directory.


<details>
    <summary><i>Show sample training outputs</i></summary>
    When training a SOLD model, you can check different visualisations to monitor the training progress. 
    The <i>dynamics_prediction</i> plot highlights the differences between the ground truth and the predicted future states, and 
    shows the forward prediction of each slot.
    <p align="center">
      <img src="assets/dynamics_reach_red.png" width="100%">
    </p>
    In addition, visualisations of <i>actor_attention</i> or <i>reward_predictor_attention</i>, as shown below, can be used to 
    understand what the model is paying attention to when predicting the current reward, i.e. which elements of the scene 
    the model considers to be reward-predictive.
    <p align="center">
      <img src="assets/reward_predictor_attention_reach_red.png" width="100%">
    </p>
</details>



For further evaluation of a trained model or a set of models in a directory, you can run:
```bash
python evaluate_sold.py checkpoint_path=PATH_TO_CHECKPOINT(S)
```
which will log performance metrics and visualizations for the given checkpoints.